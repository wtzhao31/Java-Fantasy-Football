package Controller;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public enum FantasyMenu {
	PLAY_WEEK("Play Week"),
	VIEW_TEAM("View Team"),
	VIEW_MATCHUP("View Matchup"),
	VIEW_RANKINGS("View Rankings & League Members"),
	PLAYER_STATS("Player Stats"),
	SETTINGS("Settings"),
	SAVE_AND_EXIT("Save & Exit");
	
	// FantasyMenu constructor
	private String description;
	
	private FantasyMenu(String description) {
		this.description = description;
	}
	
	// getter for the description
	public String getDescription() {
		return this.description;
	}
	
	// returns the length of FantasyMenu enum
	public static int getNumOptions() {
		return FantasyMenu.values().length;
	}
	
	// gets an Enum based on the index
	public static FantasyMenu getOption(int num) {
		return FantasyMenu.values()[num-1];// going to be -1 the index because starting the list at 1 instead of 0
	}
	public static String getMenuOptions() {
		String prompt = "************************************";
		prompt += "\nCOLLEGE FANTASY FOOTBALL LEAGUE MENU"; // put the leagueName in there??? somehow...
		int counter = 1;
		
		for(FantasyMenu fm : FantasyMenu.values()){ //array from the enum
			prompt += "\n" + counter + ". " + fm.getDescription();
			counter += 1;
		}
		prompt += "\n************************************";
		return prompt;
	}
}