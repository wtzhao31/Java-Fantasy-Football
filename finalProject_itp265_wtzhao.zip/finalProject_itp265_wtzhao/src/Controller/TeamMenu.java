package Controller;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public enum TeamMenu {
	ADD_DROP_FA("Add/drop players from free agency"),
	PROPOSE_TRADE("Propose trade"),
	EXIT_TO_MM("Exit to main menu");
	
	// FantasyMenu constructor
	private String description;
	
	private TeamMenu(String description) {
		this.description = description;
	}
	
	// getter for the description
	public String getDescription() {
		return this.description;
	}
	
	// returns the length of FantasyMenu enum
	public static int getNumOptions() {
		return TeamMenu.values().length;
	}
	
	// gets an Enum based on the index
	public static TeamMenu getOption(int num) {
		return TeamMenu.values()[num-1];// going to be -1 the index because starting the list at 1 instead of 0
	}
	
	public static String getMenuOptions() {
		String prompt = "\nOptions:"; // put the leagueName in there??? somehow...
		int counter = 1;
		
		for(TeamMenu fm : TeamMenu.values()){ //array from the enum
			prompt += "\n" + counter + ". " + fm.getDescription();
			counter += 1;
		}
		prompt += "\n";
		return prompt;
	}
}