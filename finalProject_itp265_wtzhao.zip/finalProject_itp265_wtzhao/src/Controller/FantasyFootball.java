package Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Model.*; // import stuff from the Model and View packages
import View.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


/**
 * Brief description of code: FantasyFootball Controller. This is the heart of my final project!
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Final Project
 * Email: wtzhao@usc.edu
 */
public class FantasyFootball implements java.io.Serializable{

	private Map<String,Moderator> users; // stores all the users in a map. Maps the user's email to the actual user (Moderator)
	private Moderator currentUser; // store the current user (Moderator)
	private League currentLeague; // stores the current League for easier access
	private UIConsole helper; // helper: can only be used for the controller package!
	
	public FantasyFootball() {
		users = new HashMap<>();
		helper = new UIConsole();
	}
	
	// ****************************************************************************************************************
	// ADMINISTRATIVE STUFF - SIGN IN, LOG IN, ETC...
	// the first message that the user sees when they run this program
	private void firstMessage() {
		System.out.println("Welcome to College Fantasy Football!");
		String option = helper.inputWord("If this is your first time logging in, type \"first\". If not, type \"upload\" to upload database.", "first", "upload");
		if (option.equals("first")) { // if this is the first time logging in, then call createAccount()
			createAccount(); 
		}
		else if(option.equals("upload")) {
			System.out.println("Uploading current database of known users...");
			this.users = readInCollectionsMapFromFile(); // uploads the current file. doesn't work right now
			login(); // once the database has been uploaded, then they can go login. 
		}
		
	}

	// NOTE: The basis for these login methods were borrowed from the HW09_ITPStore code, but altered for my purposes
	// Login screen: what the user will first see
	private void login() {
		helper.print("Welcome to College Fantasy Football!");
		String word = helper.inputWord("Would you like to sign in to your account or create a new account?\n" +
				"Type: \"signin\" or \"create\"", "signin", "create");
		if (word.equalsIgnoreCase("signin")) {
			signin();
		}
		else { // creating an account
			createAccount();
		}
	}
	
	// creates an account, and makes the currentUser the user who just created an account
	private void createAccount() {
		String email = helper.inputLine("Please enter your email: ");
		if (this.users.containsKey(email)) { // if this user is already taken
			helper.print("Email is already taken! Please sign in.");
			signin();
		}
		else { // if this is a new email, it will create an account for them and automatically create a league
			String name = helper.inputWord("Please enter the name to associate with account: ");
			String password = helper.inputWord("Please enter a password: ");
			Moderator m = new Moderator(name, email, password); // constructs them as a Moderator
			this.users.put(email, m); // adds the newly created user to the list of this.users
			helper.print("You have successfully created an account!");
			currentUser = m; // IN
			String createLeague = helper.inputWord("Type \"createLeague\" to create a new league!", "createLeague", "createLeague");
			createLeague(); // creates a league for them
			draft(); // then it automatically drafts
		}
	}
	
	// if the user already has an account and would like to sign in. 
	// users who already have an account will have already created a league 
	private void signin() {
		String emailInput = helper.inputLine("Please enter your email: ");
		if(users.containsKey(emailInput)) { // if their email matches one in the system
			String passwordInput = helper.inputLine("Please enter your password: ");
			if (users.get(emailInput).getPassword().equals(passwordInput)) {
				currentUser = this.users.get(emailInput); // IN. sets the current user to the one that just logged in
				helper.print("Welcome back " + currentUser.getName());
				if (currentUser.getLeague() == null) { // ONLY DOES THIS IF THEY FINSIHED THEIR PREVIOUS LEAGUE, must start a new one!
					helper.print("Looks like you don't have an ongoing League.");
					String createLeague = helper.inputWord("Type \"createLeague\" to create a new league!", "createLeauge", "createLeague");
					createLeague();
					draft();
				}
				else {
					this.currentLeague = this.currentUser.getLeague(); // sets the curent league to be the League of the user who just signed in.
				}
				// if their League is not done, it's not going to be null. Thus, it's going to go back to the run() method and go to weekByWeek().
			}
			else {
				helper.print("Incorrect Password.");
				login();
			}
		}
		else {
			String createNew = helper.inputWord("Didn't find a user with that email. Would you like to create an account? "
					+ "or return to main menu? Type: \"create\" or \"return\"","create","return");
			if(createNew.equals("create")) {
				createAccount(); // create a new account
			}
			else {
				login(); // returns to main menu
			}	
		}
	}
	
	// creates a brand new League for the Moderator and begins the draft
	//  ... = new Moderator (...) --> Type cast the FLM to a Moderator
	private void createLeague() {
		helper.print("Creating a league of 8 total players for you...");
		String leagueName = helper.inputLine("Please enter a name for your new league: ");
		currentLeague = new League(leagueName,currentUser);
		//currentLeague.getLeagueMembers().add(currentUser); // adds the currentUser to his own League's list of FLMs
		currentUser.setFantasyLeague(currentLeague); // sets their new FantasyLeague attribute as the league they just created
		String teamName = helper.inputLine("Please enter your team name: "); // once they have a teamName they are now a Moderator
		currentUser.setTeamName(teamName); // sets the teamName for the Moderator
		// may have to typecast currentUser as a Moderator every time because the List is defined to hold FLM (FantasyLeagueMembers)
	}
	
	// drafting!
	private void draft() {
		currentLeague.draft();
	}
	// ****************************************************************************************************************
	
	// ****************************************************************************************************************
	// MAIN CONTROLLER
	// controls the week by week flow of the FantasyFootballLeague
	private void weekByWeek() {
		boolean keepGoing = true;
		while(currentLeague.getWeekNumber() < 8 && keepGoing) { // playing 7 weeks, so it's going to keep going until all weeks have been played
			FantasyMenu menuItem = getMenuItem();
			switch(menuItem) {
			case PLAY_WEEK: // 1
				playWeek();
				break;
			case VIEW_TEAM: // 2
				viewTeam();
				TeamMenu teamMenuItem = getViewTeamMenuItem();
				switch(teamMenuItem) {
				case ADD_DROP_FA:
					freeAgent();
					break;
				case PROPOSE_TRADE:
					playerTrade();
					break;
				case EXIT_TO_MM: // literally doesn't do anything
					break;
				}
				break;
			case VIEW_MATCHUP: // 3
				viewMatchUp();
				break;
			case VIEW_RANKINGS: // 4
				displayRankings();
				break;
			case PLAYER_STATS:
				playerStats();
				break;
			case SETTINGS: // 5
				settings();
				break;
			case SAVE_AND_EXIT: // 6
				helper.print("Saving...");
				keepGoing = false; // turns off the while loop
				saveAndExit(); // implement this later to write the file out!
				// probably have the fileOutWriter in the League class
				break;
			} //end switch
		}
		if (this.currentLeague.getWeekNumber() > 7) {
			finishLeague();
		}
	}
	
	// 1. Play the upcoming week
	private void playWeek() {
		this.currentLeague.playWeek();
		this.currentLeague.updateWeek(); // adds the week by 1
	}
	
	// 2. View Team
	private void viewTeam() {
		this.currentLeague.displayTeamAveragePoints(this.currentUser);
	}
	
	// 2a. Adding and dropping from free agency
	private void freeAgent() {
		this.currentLeague.printFreeAgents();	
		boolean addDrop = helper.inputYesNoAsBoolean("Would you like to drop one of your players and add one from free agency? (y/n)");
		if (addDrop) {
			String positionChange = helper.inputWord("Which position would you like to swap players? Type \"QB\", \"RB\", \"WR\", \"TE\", or \"K\"", "QB", "RB", "WR", "TE", "K");
			int counter = 1;
			for (Player p: this.currentLeague.getFreeAgents().get(positionChange)) { // displaying the options
				System.out.println(counter + ". " + p.printNameCollegePosition());
				counter += 1;
			}
			System.out.println();
			int choosePlayer = helper.inputInt("Which player do you want?", 1, 2);
			Player chosenPlayer = this.currentLeague.getFreeAgents().get(positionChange).get(choosePlayer - 1);
			Player dropPlayer = this.currentUser.getTeamPlayers().get(positionChange);
			helper.print("Processing transaction...");
			System.out.println("Dropping: " + dropPlayer.printNameCollegePosition());
			System.out.println("Adding: " + chosenPlayer.printNameCollegePosition());
			// exchanging the players
			for (String position : this.currentUser.getTeamPlayers().keySet()) {
				if (positionChange.equalsIgnoreCase(position)) { // finds the "QB" or whatever position in the Moderator's Player list
					// replacing the freeAgents list with the Player that the user had before
					this.currentLeague.getFreeAgents().get(positionChange).set(choosePlayer - 1, dropPlayer);
					// replacing the player's list with the chosen player. 
					this.currentUser.getTeamPlayers().replace(position, chosenPlayer);
				}
			}
			helper.print("Your new team... \n");;
			this.currentLeague.displayTeam(this.currentUser);
		}
		else {
			helper.print("Returning to main menu...");
		}
	}
	
	// 2b. Trading with other players!
	private void playerTrade() {
		this.currentLeague.displayRankings();
		int teamToTrade = helper.inputInt("Which team would you like to trade with?", 1, this.currentLeague.getLeagueMembers().size());
		LeagueMember lmTrade = this.currentLeague.getLeagueRankings().get(teamToTrade - 1); // the player they want to trade with
		this.currentLeague.displayTeamAveragePoints(lmTrade); // displays the other LeagueMember's team
		System.out.println();
		System.out.println("Your team...");
		this.currentLeague.displayTeamAveragePoints(this.currentUser); // displays the user's team
		String positionChange = helper.inputWord("Which position would you like to swap players? Type \"QB\", \"RB\", \"WR\", \"TE\", or \"K\"", "QB", "RB", "WR", "TE", "K");
		Player tempPlayer = this.currentUser.getTeamPlayers().get(positionChange); // creates a temporary spot in memory for the traded player
		Player tradeForPlayer = lmTrade.getTeamPlayers().get(positionChange); // trade-for player
		System.out.println("Proposed trade: \nYou trade: " + tempPlayer.printNameCollegePosition() + "\nYou receive: " + tradeForPlayer.printNameCollegePosition());
		int probabilityTrade = UIConsole.randomIntInRange(1, 10);
		if (probabilityTrade > 5) { // 50-50 chance the trade goes through
			System.out.println(lmTrade.getTeamName() + " has approved your trade!");
			this.currentUser.getTeamPlayers().replace(positionChange, tradeForPlayer); // replaces the Moderator's Player with the trade-for player
			lmTrade.getTeamPlayers().replace(positionChange,tempPlayer); // replaces the other user's (CPU) Player for the trade player 
			System.out.println("Transaction successful!");
		}
		else {
			System.out.println(lmTrade.getTeamName() + " has denied your trade.");
		}
	}
	
	// 3. View the week's matchup
	private void viewMatchUp() {
		helper.print("Viewing matchup...");
		this.currentLeague.viewMathup();
	}
	
	// 4. Display the rankings and viewing other teams
	private void displayRankings() {
		this.currentLeague.displayRankings();
		int option = helper.inputInt("Type the number whose team you would like to view, or press 0 to go back.", 1, this.currentLeague.getLeagueMembers().size(), 0);
		if (option > 0) {
			this.currentLeague.displayTeamAveragePoints(this.currentLeague.getLeagueRankings().get(option - 1));
		}
	}
	
	// 5. Player stats
	private void playerStats() {
		String position = helper.inputWord("Choose position: \"QB\", \"RB\", \"WR\", \"TE\", or \"K\"", "QB", "RB", "WR", "TE", "K");
		this.currentLeague.playerStats(position);

	}
	
	// 6. Settings: didn't get around to doing this :(
	private void settings() {
		helper.print("Settings. Was going to do some JOptionPane stuff, but didn't get around to it.");
	}
	
	// 7. Save to file and exit
	private void saveAndExit() {
		writeMapToFile("src/savedUsers.ser",this.users);
	}
	
	// When all the games have been played: display the final rankings
	private void finishLeague() {
		helper.print("That is the end of this league!");
		helper.print("Here are the final rankings!");
		currentLeague.displayRankings(); // display the rankings one last time, also sorts the rankings too
		int ranking = 0;
		for (LeagueMember lm : currentLeague.getLeagueRankings()) { // loops through the rankings
			if(lm instanceof Moderator) { // finding the Moderator
				ranking = currentLeague.getLeagueRankings().indexOf(lm) + 1; // gets the index of the Moderator, then adds one
			}
		}
		helper.print("Your final finish: Rank #" + ranking);
		if(ranking == 1) { // displays this only if they finished in first place. 
			helper.print("Congratulations! You are the champion of " + "\"" + this.currentLeague.getLeagueName() + "\"");
			// Idea: when they win, it gets added to one of their attributes, "Number of League Championships"
		}
		else if (ranking > 1 && ranking < 5) { // finished place 2-4
			helper.print("Good job! You competed well in " + "\"" + this.currentLeague.getLeagueName() + "\"");
		}
		else {
			helper.print("Oof. You finished in the bottom half of" + "\"" + this.currentLeague.getLeagueName() + "\"" + ". Better luck next time!");
		}
		this.currentUser.reset(); // resets information like their number of wins, total points scored, etc... 
		// creating a new league
		boolean startNewLeague = helper.inputYesNoAsBoolean("Would you like to start a new League (y/n)?");
		if (startNewLeague) {
			createLeague(); // creates a new League, which will set the Moderator.fantasyLeague to the new one
			draft(); // sets up the draft
			weekByWeek(); // goes back to the week by week loop, which will end up here if they finish
		}
		else {
			this.currentUser.setFantasyLeague(null); // erases their current league
			saveAndExit();
		}
	}
	
	// method borrowed from ITPStore
	private FantasyMenu getMenuItem() {
		String menu = FantasyMenu.getMenuOptions();
		int input = helper.inputInt(menu, 1, FantasyMenu.getNumOptions());
		return FantasyMenu.getOption(input);
	}
	
	// method borrwed from ITPStore
	// returns the option
	private TeamMenu getViewTeamMenuItem() {
		String menu = TeamMenu.getMenuOptions();
		int input = helper.inputInt(menu, 1, TeamMenu.getNumOptions());
		return TeamMenu.getOption(input);
	}
	
	// borrowed from last day of class
	private void writeMapToFile(String fileName, Map myMap) {
		//for this to work, contents in the Map MUST be Serializable, which means it can be written to a file
		// anything with a Scanner or Helper as instance variable can not be serializable.
		//System.out.println("** demo serializable. which is basically writing data to machine-readable data");
		try (FileOutputStream fs = new FileOutputStream(fileName)){
			System.out.println("\t writing to file: " + fileName);
			ObjectOutputStream os = new ObjectOutputStream(fs);
			os.writeObject(myMap); //write the MAP object (ANY Java object that is serializable)
			os.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// borrowed from last day of class
	private Map<String, Moderator> readInCollectionsMapFromFile() {
		Map<String, Moderator>tempMap = null ;
		try (FileInputStream fs = new FileInputStream("src/savedUsers.ser");
				ObjectInputStream os = new ObjectInputStream(fs)){
			Object o = os.readObject();
			if(o instanceof Map) {
				tempMap = (Map<String, Moderator>)o; // type cast, because reading in files on reads in Objects
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Error caught in readInCollectionsMapFromFile, no file found to read a map.");
		}
		if(tempMap == null) {
			System.out.println("Error reading map in from file, will need to create new empty map :-(");
			tempMap = new HashMap<>();
		}
		System.out.println("New temp map contains: " + tempMap);
		return tempMap;
	}
	
	private void endProgram() {
		helper.print("Done.");
	}
	// ****************************************************************************************************************
	
	// runs the program
	private void run() {
		firstMessage();
		weekByWeek();
		endProgram();
	}
	
	// The main method of this final project!
	public static void main(String[] args) {
		FantasyFootball ff = new FantasyFootball();
		ff.run();
	}
}
