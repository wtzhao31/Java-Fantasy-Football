package Model;

import java.util.*;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class LeagueMember extends FantasyLeagueMember implements Comparable<LeagueMember>, java.io.Serializable{ // may need to implement comparable

	private String teamName;
	private Map<String,Player> teamPlayers; // maps position to player
	private ArrayList<Double> pointsScoredByWeek;
	private int numWins;
	private int numLosses;
	//private String record;
	
	public LeagueMember(String name, String email, String password, String teamName) {
		super(name, email, password);
		this.teamName = teamName;
		this.teamPlayers = new HashMap<>(); // need to declare the keys right now? QB, RB, WR, TE, K? Probably not, going to be drafting in specific order
		this.pointsScoredByWeek = new ArrayList<>();
		//for (int i = 0; i < 10; i++) { // initializes the total points scored to be 0. 
		//	pointsScoredByWeek.set(i, 0.0);
		//}
		this.numWins = 0;
		this.numLosses = 0; // gets the record of the player (W-L)
	}

	// getters 
	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String name) { // you can change your team name --> will go into the settings
		this.teamName = name;
	}
	
	public Map<String, Player> getTeamPlayers() {
		return teamPlayers;
	}

	public ArrayList<Double> getPointsScoredByWeek() {
		return pointsScoredByWeek;
	}
	
	// sets a LeagueMember's points scored in a week to whatever the individual Players scored in that week, added all together
	public void setPointsScoredByWeek(int week) {
		double sum = 0.0;
		for (Player p: this.teamPlayers.values()) { // loops through all of the Players
			sum += p.getPointsByWeek(week); // sums up each individual Player's points per week
		}
		this.getPointsScoredByWeek().add(week - 1, sum); // sets that sum to that the position
	}
	
	// returns the TOTAL amount of points a User has scored
	public double totalPointsScored() {
		double sum = 0;
		for (double d: this.pointsScoredByWeek) {
			sum = sum + d;
		}
		return sum;
	}
	
	public int getNumWins() {
		return numWins;
	}

	public int getNumLosses() {
		return numLosses;
	}

	public void addWin() {	// need to be able to update the wins and losses
		this.numWins += 1;
	}

	public void addLoss() {
		this.numLosses += 1;
	}
	
	public String getRecord() {
		return "(" + this.numWins + "-" + this.numLosses + ")";
	}

	// WAYS TO DISPLAY A TEAM
	// **************************************************************************************************************************************************************************
	
	// TODO: probably won't work until after the draft, when .players gets filled
	// TODO: do I want to have the players as a map? 
	// displays the team in a numbered order
	// 1. QB: Justin Fields, Ohio State
	// 2. RB: Travis Etienne, Clemson
	public void displayTeam() {
		System.out.println(displayTeamNameRecordPoints());
		int num = 1;
		for (String s: this.teamPlayers.keySet()) {
			System.out.println(num + ". " + this.teamPlayers.get(s).printNameCollegePosition());
			num += 1;
		}
	}
	
	public void displayTeamAveragePoints(int week) {
		System.out.println(displayTeamNameRecordPoints());
		int num = 1;
		for (String s: this.teamPlayers.keySet()) {
			System.out.println(num + ". " + this.teamPlayers.get(s).printAveragePointsScored(week));
			num += 1;
		}
	}
	
	// displays something like:
	// Team1, User1 (0-0)
	public String displayTeamAndName() {
		return this.teamName + ", " + this.name + " " + this.getRecord();
	}
	
	// displays:
	// Team1, User1 (0-0) Total points: 0.0
	public String displayTeamNameRecordPoints() {
		return this.teamName + ", " + this.name + " " + this.getRecord() + " Total points: " + this.totalPointsScored();
	}
	
	// displays like this:
	// QB: Justin Fields - 20.14 points
	// ...
	// Total week 1 points: 80.4 points
	public void displayTeamPoints(int weekNumber) {
		//calcPointsByWeek(weekNumber);
		for(Player p : this.getTeamPlayers().values()) { // looping through the Players of m, the user
			System.out.println(p.printPointsScored(weekNumber)); 
		}
		System.out.println("Total week " + weekNumber + " points: " + this.getPointsScoredByWeek().get(weekNumber - 1) + " points");
	}
	
	// **************************************************************************************************************************************************************************

	public void reset() { // RESET: the wins and losses both become 0, sets all of the points to be 0
		this.numWins = 0;
		this.numLosses = 0;
		for(int i = 0; i < 7; i++) {
			this.pointsScoredByWeek.set(i, 0.0);
		}
	}

	
	// calculates the points scored for each player on the team
	public void calcPointsByWeek(int weekNumber) {
		for(Player p : this.getTeamPlayers().values()) { // looping through the Players of m, the user
			p.calcWeeklyPoints(weekNumber - 1); // calculates their weekly points
		}
		this.setPointsScoredByWeek(weekNumber);
	}
	
	@Override
	public String toString() {
		return "LeagueMember " + super.toString() + " [teamName=" + teamName + ", record=" + this.getRecord() + ", totalPointsScored=" + this.totalPointsScored()
				+ "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + numLosses;
		result = prime * result + numWins;
		result = prime * result + ((pointsScoredByWeek == null) ? 0 : pointsScoredByWeek.hashCode());
		result = prime * result + ((teamName == null) ? 0 : teamName.hashCode());
		result = prime * result + ((teamPlayers == null) ? 0 : teamPlayers.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		LeagueMember other = (LeagueMember) obj;
		if (numLosses != other.numLosses)
			return false;
		if (numWins != other.numWins)
			return false;
		if (pointsScoredByWeek == null) {
			if (other.pointsScoredByWeek != null)
				return false;
		} else if (!pointsScoredByWeek.equals(other.pointsScoredByWeek))
			return false;
		if (teamName == null) {
			if (other.teamName != null)
				return false;
		} else if (!teamName.equals(other.teamName))
			return false;
		if (teamPlayers == null) {
			if (other.teamPlayers != null)
				return false;
		} else if (!teamPlayers.equals(other.teamPlayers))
			return false;
		return true;
	}

	// compares the LeagueMembers first by number of wins, then by the total points scored, then by their name
	public int compareTo(LeagueMember other) {
		if (this.equals(other)) return 0;
		Integer thisNumWins = this.getNumWins();
		Double thisTotalPoints = this.totalPointsScored();
		int comparisonVal = -1 * thisNumWins.compareTo(other.getNumWins()); // comparing the number of wins first
		if (comparisonVal == 0) { // if they have the same number of wins...
			comparisonVal = -1 * thisTotalPoints.compareTo(other.totalPointsScored()); // compare the total points scored
			if (comparisonVal == 0) { // in the off chance that they have the exact same number of total points scored...
				comparisonVal = this.getName().compareTo(other.getName()); // just compare their name
			}
		}
		return comparisonVal;
	}
	
	// may potentially need a comparable method to sort LeagueMembers by number of wins, then totalPoints scored
	// that way it will be easier to display Rankings
	
}
