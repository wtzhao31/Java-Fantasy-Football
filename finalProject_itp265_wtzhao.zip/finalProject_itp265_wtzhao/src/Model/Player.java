package Model;

import java.util.*;

import View.UIConsole;


/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public abstract class Player implements java.io.Serializable, Comparable<Player>{ //implements Comparable<Player>{
	private String name;
	private String collegeTeam;
	private String position;
	private String height;
	private String weight;
	private String year;
	private String birthPlace;
	private Rating rating;
	private String fantasyTeam;
	private boolean isFreeAgent;
	
	private ArrayList<Double> totalPoints;// List of all the points they score per week
	// private LeagueMember fantasyOwner;
	
	protected UIConsole ui;

	// Constructing a player (reading from a file)
	public Player(String name, String collegeTeam, String position, String height, String weight, String year,
			String birthPlace, Rating rating) {
		this.name = name;
		this.collegeTeam = collegeTeam;
		this.position = position;
		this.height = height;
		this.weight = weight;
		this.year = year;
		this.birthPlace = birthPlace;
		this.rating = rating;
		
		this.isFreeAgent = true;
		this.ui = new UIConsole();
		this.fantasyTeam = "Free Agent";
		
		this.totalPoints = new ArrayList<>(); // initializes the amount of points to empty list of size 10 (10 week schedule)
		for (int i = 0; i < 10; i++) {
			this.totalPoints.add(0.0);
		}
	}
	
	public Player(String name) {
		this(name,"college","position","height","weight","year","birthPlace", Rating.HEISMAN);
		this.isFreeAgent = true;
		this.ui = new UIConsole();
		this.fantasyTeam = "Free Agent";
		
		this.totalPoints = new ArrayList<>(); // initializes the amount of points to empty list of size 10 (10 week schedule)
		for (int i = 0; i < 10; i++) {
			this.totalPoints.add(1.0);
	}
	}

	// getters and setters
	public boolean isFreeAgent() {
		return isFreeAgent;
	}

	public void setFreeAgent(boolean isFreeAgent) {
		this.isFreeAgent = isFreeAgent;
	}

	public String getName() {
		return name;
	}

	public String getCollegeTeam() {
		return collegeTeam;
	}

	public String getPosition() {
		return position;
	}

	public String getHeight() {
		return height;
	}

	public String getWeight() {
		return weight;
	}

	public String getYear() {
		return year;
	}

	public String getBirthPlace() {
		return birthPlace;
	}

	public Rating getRating() {
		return rating;
	}
	
	public String getFantasyTeam() { // NEW: gets the Fantasy team that they are on
		return fantasyTeam; // just another piece of information that I can put on display
	}

	public void setFantasyTeam(String fantasyTeam) {
		this.fantasyTeam = fantasyTeam;
	}

	public ArrayList<Double> getPoints() {
		return totalPoints;
	}
	
	// returns the number of points scored in a given week
	public double getPointsByWeek(int week) {
		return this.getPoints().get(week - 1);
	}
	
	// gets the total amount of points a player has scored
	public double getTotalPoints() {
		double sum = 0.0;
		for (double d : this.getPoints()) {
			sum += d;
		}
		return sum;
	}
	
	// this method should never get called because the child classes have this, so it should be overidden
	public void calcWeeklyPoints(int week) {
		System.out.println("GLITCH=! Calculating weekly points PLAYER. week #: " + week);
	}
	
	// summing arrays of ints
	public int sumInt(List<Integer> list) {
		int sum = 0;
		for (Integer i : list) {
			sum += i;
		}
		return sum;
	}
	
	// summing arrays of doubles
	public double sumDouble(List<Double> list) {
		double sum = 0.0;
		for (Double d : list) {
			sum += d;
		}
		return sum;
	}
	
	// ********************************************************************************************************************************************************
	// DISPLAYING
	
	// prints this format:
	// QB: Justin Fields, Ohio State
	public String printNameCollegePosition() {
		return this.position + ": " + this.name + ", " + this.collegeTeam;
	}
	
	// QB: Justin Fields
	public String printPositionName() {
		return this.position + ": " + this.name;
	}
	
	// QB: Justin Fields - 20.0 points
	public String printPointsScored(int week) {
		return this.position + ": " + this.name + " - " + this.getPoints().get(week - 1) + " points";
	}
	
	// printing the average points scored by a Player up until a certain week
	// QB: Justin Fields, Ohio State - Average points per week: 25.0
	public String printAveragePointsScored(int week) {
		double averagePoints = 0.0;
		if (week != 0) {
			averagePoints = this.getTotalPoints() / week; // calculates the average amount of points scored
		}
		return this.position + ": " + this.name + ", " + this.collegeTeam + " - Average points per week: " + averagePoints;
	}
	
	// ********************************************************************************************************************************************************

	// TODO: Fix the toString() format to suit whatever needs for the the Controller
	@Override
	// displays all of player information --> when user wants to "zoom in" and see more about the player
	public String toString() { 
		return "[name=" + name + ", collegeTeam=" + collegeTeam + ", position=" + position + ", height=" + height
				+ ", weight=" + weight + ", year=" + year + ", birthPlace=" + birthPlace + ", rating = " + rating + ", fantasyTeam = "
				+ fantasyTeam;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((birthPlace == null) ? 0 : birthPlace.hashCode());
		result = prime * result + ((collegeTeam == null) ? 0 : collegeTeam.hashCode());
		result = prime * result + ((height == null) ? 0 : height.hashCode());
		result = prime * result + (isFreeAgent ? 1231 : 1237);
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((totalPoints == null) ? 0 : totalPoints.hashCode());
		result = prime * result + ((position == null) ? 0 : position.hashCode());
		result = prime * result + ((rating == null) ? 0 : rating.hashCode());
		result = prime * result + ((weight == null) ? 0 : weight.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Player other = (Player) obj;
		if (birthPlace == null) {
			if (other.birthPlace != null)
				return false;
		} else if (!birthPlace.equals(other.birthPlace))
			return false;
		if (collegeTeam == null) {
			if (other.collegeTeam != null)
				return false;
		} else if (!collegeTeam.equals(other.collegeTeam))
			return false;
		if (height == null) {
			if (other.height != null)
				return false;
		} else if (!height.equals(other.height))
			return false;
		if (isFreeAgent != other.isFreeAgent)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (totalPoints == null) {
			if (other.totalPoints != null)
				return false;
		} else if (!totalPoints.equals(other.totalPoints))
			return false;
		if (position == null) {
			if (other.position != null)
				return false;
		} else if (!position.equals(other.position))
			return false;
		if (rating != other.rating)
			return false;
		if (weight == null) {
			if (other.weight != null)
				return false;
		} else if (!weight.equals(other.weight))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}
	
	// compares the Players based on their stats
	public int compareTo(Player other) {
		if (this.equals(other)) return 0;
		Double thisTotalPoints = this.getTotalPoints(); // just compares the points from PASSING
		Double otherTotalPoints = other.getTotalPoints();
		int comparisonVal = -1 * thisTotalPoints.compareTo(otherTotalPoints);
		if (comparisonVal == 0) {
			comparisonVal = this.getName().compareTo(other.getName()); // just compares their names if they have the same total points
		}
		return comparisonVal;
	}
	
	/*
	public static void main(String[] args) {
		Player p = new Player("winfield");
		System.out.println(p.totalPoints);
	}*/
	
}
