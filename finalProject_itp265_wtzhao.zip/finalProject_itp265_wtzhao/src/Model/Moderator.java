package Model;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */

// every user is going to be a Moderator, and they have settings to control the league
// so far, all they can do is change the interface from either popups or the console window
// other potential methods that the moderator could have: 
public class Moderator extends LeagueMember implements java.io.Serializable{

	private boolean popUpInterface;
	private League fantasyLeague;
	
	public Moderator(String name, String email, String password, String teamName) {
		super(name, email, password, teamName);
		this.popUpInterface = false; // use console window to start out with
		this.fantasyLeague = null; // doesn't have a League to start out with
	}
	
	public Moderator(String name, String email, String password) { // can construct a Moderator without the teamName just yet
		this(name, email, password, "Team00");
		this.popUpInterface = false; // use console window to start out with
		this.fantasyLeague = null;

	}

	// getters and setters
	public League getLeague() {
		return fantasyLeague;
	}

	public void setFantasyLeague(League fantasyLeague) {
		this.fantasyLeague = fantasyLeague;
	}

	public boolean isPopUpInterface() {
		return popUpInterface;
	}
	
	public void setPopUpInterface(boolean popUpInterface) {
		this.popUpInterface = popUpInterface;
	}
	
	public void addPlayer(String position, Player playerSelect) {
		this.getTeamPlayers().put(position,playerSelect); // adds the selected player into the LeagueMember's list of Players
	}
	
	/*
	@Override
	public String toString() {
		return super.toString() + this.fantasyLeague;
	}
	*/
	
}
