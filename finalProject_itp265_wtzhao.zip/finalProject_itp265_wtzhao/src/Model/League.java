package Model;

import java.util.*;

import View.UIConsole;
/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class League implements java.io.Serializable {

	private String leagueName;
	private int weekNumber; // keeps track of the week number
	private List<FantasyLeagueMember> leagueMembers; // list of FantasyLeagueMembers --> the order of this List will change because of the rankings (using the compareTo)
	private List<LeagueMember> opponents; // ArrayList of opponents for the Moderator. Will not be sorted, remain fixed				// *****
	private List<LeagueMember> leagueRankings;
	private List<Player> allPlayers; // all the Players that gets read in from the file
	private Map<String,List<Player>> freeAgents; // maps position to a list of Players
	//private Moderator m;
	transient private UIConsole helper;
	//private UIConsole helper;
	//private String fileName; --> can pass in a fileName for every League object
	
	public League(String leagueName, Moderator m) { // what do we need to create a NEW League? --> just the leagueName and the Moderator
		this.leagueName = leagueName;
		this.weekNumber = 1;
		this.leagueMembers = new ArrayList<>();
		this.opponents = new ArrayList<>();
		createCpuUsers(); // creates the 7 fake users and adds them to the list of leagueMembers whenever a new league gets constructed!
		this.leagueMembers.add(m);
		this.leagueRankings = new ArrayList<>();
		for(FantasyLeagueMember flm: this.leagueMembers) { // sets the leagueRankings to have all of the leagueMembers
			LeagueMember lm = (LeagueMember) flm;
			this.leagueRankings.add(lm);
		}
		PlayerFactory p = new PlayerFactory("src/Players.tsv"); // uses the PlayerFactory class to make all of the free agents
		this.allPlayers = p.getAllPlayers();
		this.freeAgents = new HashMap<>();
		//this.m = m; // sets the moderator 
		this.helper = new UIConsole();
	}
	
	// getters & setters
	public int getWeekNumber() {
		return this.weekNumber;
	}

	// increases the week by 1 when advancing week 
	public void updateWeek() { 
		this.weekNumber += 1; 
	}
	
	public String getLeagueName() {
		return leagueName;
	}

	public List<FantasyLeagueMember> getLeagueMembers() {
		return leagueMembers;
	}
	
	// returns the league rankings
	public List<LeagueMember> getLeagueRankings() {
		return leagueRankings;
	}
	
	public List<Player> getAllPlayers(){
		return allPlayers;
	}

	public Map<String,List<Player>> getFreeAgents() {
		return freeAgents;
	}

	
	
	public void createCpuUsers() { // creates 7 fake users
		int num = 1;
		while (num < 8) {
			String name = "User" + num;
			String email = name + "@usc.edu";
			String password = "Password" + num;
			String teamName = "Team" + num;
			LeagueMember l = new LeagueMember(name, email, password, teamName);
			this.leagueMembers.add(l); // adds each fake user to the total list of users
			this.opponents.add(l); // also adds the fake user to the list of opponents the Moderator will face 
			num += 1; // adds one to the counter
		}
	}

	// drafting!
	public void draft() {
		System.out.println("Generating draft positions...");
	//	timeDelay(3000);
		int randomNumber = UIConsole.randomIntInRange(0, 7); // generating a random number to swap places with
		// the Moderator will always be at position 7 b/c he is the last LeagueMember created. Switch his place with the random number
		Collections.swap(this.leagueMembers, 7, randomNumber); // found this code at "howtodoinjava.com"
		System.out.println("Welcome to the " + this.leagueName + " draft!\n");
	//	timeDelay(1000);
		System.out.println("*****DRAFT ORDER*****");
		int counter = 1;
		for (FantasyLeagueMember flm : this.leagueMembers) {
			LeagueMember lm = (LeagueMember) flm; // type cast to LeagueMember so I have access to those methods
			System.out.println(counter + ". " + lm.getTeamName() + ": " + lm.getName());
			counter +=1;
		}
	//	timeDelay(1000);
		String[] positions = {"QB","RB","WR","TE","K"}; // fixed sized array of all the positions
		for (int i = 0; i < positions.length; i++) { // loops through this array. Drafting all the positions
			draftPosition(positions[i],i+1);
	//		timeDelay(2000);
		}
		Collections.swap(this.leagueMembers, 7, randomNumber); // swaps the user back to the last position
		System.out.println("Draft has concluded! Here are the teams: ");
	//	timeDelay(2000);
		for (FantasyLeagueMember flm: this.leagueMembers) {
				LeagueMember lm = (LeagueMember) flm; // typecast to get access to the LeagueMember's methods and stuff
				System.out.println("\n" + lm.getTeamName() + ", " + lm.getName() + ": ");
				for(String s : lm.getTeamPlayers().keySet()) {
					System.out.println(lm.getTeamPlayers().get(s).printNameCollegePosition()); 
					// Team1, User1:
					// 		QB: Justin Fields
					// 		RB: Najee Harris etc...
			}
		}
		// adding players to the freeAgents list
		for(Player p : allPlayers) { // loops through the entire Players list allPlayers
			if(p.isFreeAgent()) { // checks to see if they are a free agent. If they've been drafted, then I should have already set their 
								  // free agent status to be false. Players who were not drafted 
				if(this.freeAgents.containsKey(p.getPosition())) { // if there is already a QB/position in the freeAgents
					this.freeAgents.get(p.getPosition()).add(p);
				}
				else { // if it doesn't have the key
					this.freeAgents.put(p.getPosition(), new ArrayList<>());
					this.freeAgents.get(p.getPosition()).add(p);
				}
			}
		}
	}
	
	// Goes through one round of a draft (drafting a particular position)
	public void draftPosition(String position, int round) {
		System.out.println("ROUND " + round + ": SELECT A " + position); // fix the draft #
	//	timeDelay(3000);
		ArrayList<Player> playersByPosition = new ArrayList<>(); // creates an AraryList for the players by their position
		for(Player p: this.allPlayers) { // sifts through the allPlayers List
			if(p.getPosition().equals(position)) { // if the freeAgent is equal to the position they are drafting for
				playersByPosition.add(p); // adds the player to the playersByPosition ArrayList
			}
		}
		for(FantasyLeagueMember flm : this.leagueMembers) { // loop through all of the leagueMembers
			for(Player p : playersByPosition) {
				System.out.println((playersByPosition.indexOf(p) + 1) + ". " + p.printNameCollegePosition()); // prints the player, with a number in front
				// 1. QB: Justin Fields, Ohio State
			}
			System.out.println();
			if (flm instanceof Moderator) { // if you are a Moderator, you can make your pick
				String s = flm.getName() + ", select a " + position + ". (1-" + playersByPosition.size() + ")";
				// TODO ****************
				int playerSelectNum = helper.inputInt(s, 1, playersByPosition.size()); // selecting a player
				Player playerSelect = playersByPosition.get(playerSelectNum -1);
				playerSelect.setFreeAgent(false);
				Moderator m = (Moderator) flm; // typecast
				playerSelect.setFantasyTeam(m.getTeamName()); // changes the teamName
				m.getTeamPlayers().put(position,playerSelect); // adds the selected player into the LeagueMember's list of Players
				System.out.println(m.getName() + " has selected " + playerSelect.printNameCollegePosition() + "\n");
				playersByPosition.remove(playerSelectNum - 1); // removes that player from the list, so they can't be drafted again
				//this.freeAgents.remove(playerSelect.getName());
			}
			else { // if the user drafting is not a Moderator (aka a computer), then they are going to be fake drafting
				System.out.println(flm.getName() + ", select a " + position + ". (1-" + playersByPosition.size() + ")"); // just prints the statement
		//		timeDelay(2000);
				int randomDraftPickNum = helper.randomIntInRange(1, playersByPosition.size()); // randomly generates a number between 1 and however many players are left
				Player playerSelect = playersByPosition.get(randomDraftPickNum - 1);
				System.out.println(randomDraftPickNum); // prints the random pick number
				playerSelect.setFreeAgent(false);
				LeagueMember lm = (LeagueMember) flm;
				playerSelect.setFantasyTeam(lm.getTeamName()); // changes the teamName
				lm.getTeamPlayers().put(position, playerSelect); // adds that player to the team
				System.out.println(lm.getName() + " has selected " + playerSelect.printNameCollegePosition() + "\n");
				playersByPosition.remove(randomDraftPickNum - 1); // removes that player from the list, so they can't be drafted again
				//this.freeAgents.remove(playerSelect.getName());
			}
		}
	}
	
	// 1. plays the week
	public void playWeek() {
		/*
		for (FantasyLeagueMember flm: this.leagueMembers) {
			LeagueMember lm = (LeagueMember) flm;
			lm.calcPointsByWeek(weekNumber);
		}*/
		
		// calculates everybody's scores for that week
		for (Player p: this.allPlayers) {
			p.calcWeeklyPoints(this.weekNumber - 1);
		}
		
		// sets the points scored for that week in each of the leagueMember's points scored list
		for (FantasyLeagueMember flm: this.leagueMembers) {
			LeagueMember lm = (LeagueMember) flm;
			lm.setPointsScoredByWeek(weekNumber);;
		}
		
		//Moderator m = (Moderator) this.leagueMembers.get(7); // gets the user
		// finding the Moderator
		Moderator m = null;
		for (FantasyLeagueMember flm: this.leagueMembers) {
			if (flm instanceof Moderator) {
				m = (Moderator) flm;
			}
		}
		
		// Displays the matchup between the user and the fake opponent
		System.out.println("***** PLAYING WEEK *****");
		LeagueMember opponent = this.opponents.get(this.weekNumber - 1); // sets the opponent to be in order. e.g., Week 1: the first fake User
		System.out.println(m.displayTeamAndName() + " vs. " + opponent.displayTeamAndName() + "\n");
		//System.out.println(m.getTeamPlayers().values().getPoints());
		m.displayTeamPoints(this.weekNumber);
		System.out.println("\n");
		opponent.displayTeamPoints(this.weekNumber);
		determineWinner(m,opponent);; // analyzing who won
		System.out.println("\n" + printWinner(m,opponent)); // prints the winner
		System.out.println("***************************");
		
		// Simulate the other games
		this.opponents.remove(this.weekNumber - 1); // remove the Moderator's opponent (User_remove)
		for (int i = 0; i < this.opponents.size(); i+=2) { // loops through half the size of the this.opponents List, because repeat 3 times
			determineWinner(this.opponents.get(i),this.opponents.get(i+1)); // determines the winner between the two LeagueMember
		}
		this.opponents.add(this.weekNumber - 1, opponent); // adds the oponent back to the opponents List
		
		// see who won between 2 & 3, 4 & 5, 6 & 7 --> update their record
				// the adjacent two LeagueMembers will face each other. Always make it like this
		// add User_removed back to where it was before
	}
	
	// returns the winner between two LeagueMembers
	// edits the wins and losses
	public void determineWinner(LeagueMember i, LeagueMember j) {
		double iPoints = i.getPointsScoredByWeek().get(this.weekNumber - 1);
		double jPoints = j.getPointsScoredByWeek().get(this.weekNumber - 1);
		if(iPoints > jPoints) {
			i.addWin();
			j.addLoss();
		}
		else {
			i.addLoss();
			j.addWin();
		}
	}
	
	// between two LeagueMembers, prints the winner of the two
	// i wins, 100-90
	public String printWinner(LeagueMember i, LeagueMember j) {
		double iPoints = i.getPointsScoredByWeek().get(this.weekNumber - 1);
		double jPoints = j.getPointsScoredByWeek().get(this.weekNumber - 1);
		if (iPoints > jPoints) {
			return i.displayTeamAndName() + " wins, " + iPoints + " - " + jPoints;
		}
		else {
			return j.displayTeamAndName() + " wins, " + jPoints + " - " + iPoints;
		}
	}
	
	// 2. Display Team
	public void displayTeam(LeagueMember lm) {
		System.out.println("*************** VIEWING TEAM " + lm.getTeamName() + " ***************");

		System.out.println(lm.getTeamName() + ", " + lm.getName() + " " + lm.getRecord() + " Total points: " + lm.totalPointsScored()); // team name, background information
		int num = 1;
		for (String s: lm.getTeamPlayers().keySet()) {
			System.out.println(num + ". " + lm.getTeamPlayers().get(s).printNameCollegePosition());
			num += 1;
		}
		System.out.println("**************************************************************");

	}
	
	// same as above, but prints the team with the players' average scores
	public void displayTeamAveragePoints(LeagueMember lm) {
		System.out.println("***** VIEWING TEAM " + lm.getTeamName() + " *****");
		System.out.println(lm.getTeamName() + ", " + lm.getName() + " " + lm.getRecord() + " Total points: " + lm.totalPointsScored()); // team name, background information
		int num = 1;
		for (String s: lm.getTeamPlayers().keySet()) {
			
			System.out.println(num + ". " + lm.getTeamPlayers().get(s).printAveragePointsScored(this.weekNumber - 1)); // takes average of everything up until that week
			num += 1;
		}
		System.out.println("******************************************");

	}
	
	// 2a. Free Agents
	// Displays like this:
	// List of RB's available:
	// 1. RB: Master Teague III, Ohio State - Average points per week: 10.4
	// 2. RB: CJ Verdell, Oregon - Average points per week: 5.5
	public void printFreeAgents() {
		System.out.println("******************************* VIEWING FREE AGENTS *******************************");
		for (String s: this.freeAgents.keySet()) {
			System.out.println("List of " + s + "'s available:");
			int counter = 1;
			for (Player p: this.freeAgents.get(s)) {
				System.out.println(counter + ". " + p.printAveragePointsScored(this.weekNumber - 1));
				counter += 1;
			}
			System.out.println();
		}
		System.out.println("************************************************************************************");

	}
	
	// 3. View Matchup
	public void viewMathup() {
		// finding the Moderator
		Moderator m = null;
		for (FantasyLeagueMember flm: this.leagueMembers) {
			if (flm instanceof Moderator) {
				m = (Moderator) flm;
			}
		}
		System.out.println("***** VIEWING MATCHUP *****");
		System.out.println(      "Week " + this.weekNumber + " Matchup");
		LeagueMember opponent = (LeagueMember) this.opponents.get(this.weekNumber - 1); // sets the opponent to be in order. e.g., Week 1: the first fake User
		System.out.println(m.displayTeamAndName() + " vs. " + opponent.displayTeamAndName() + "\n");
		displayTeam(m); // displays the Moderator's team --> calls the method within the League Class
		System.out.println("\n");
		displayTeam(opponent); // displays the opponent's team
		System.out.println("***************************");
	}
	
	// 4. Display Rankings
	// displays the rankings according to number of wins, then number of total points scored, etc...
	public void displayRankings() {
		Collections.sort(leagueRankings);
		System.out.println("***** VIEWING RANKINGS *****");
		System.out.println("        Week " + this.weekNumber + " Rankings");
		int counter = 1;
		for (LeagueMember lm : this.leagueRankings) {
			System.out.println(counter + ". " + lm.displayTeamNameRecordPoints());
			counter += 1;
		}
		System.out.println("****************************");
	}
	
	// 5. Player Stats
	public void playerStats(String position) {		
		System.out.println("***** VIEWING PLAYER STATS *****");
		List<Player> players = new ArrayList<>();
		System.out.println("**** " + position + " stats as of week " + this.weekNumber + " ****");
		System.out.println();
		for (Player p: this.allPlayers) {
			if (p.getPosition().equals(position)) {
				players.add(p);
			}
		}
		Collections.sort(players); // should sort by total points by passing 
		for (int i = 0; i < players.size(); i++) { // only print out the top 5 QBs
			System.out.println((i+1) + ". " + players.get(i));
		}
		System.out.println("****************************");
	}
	
	@Override
	public String toString() {
		return "League [leagueName=" + leagueName + ", weekNumber=" + weekNumber + ", leagueMembers=" + leagueMembers
				+ "]";
	}
	
	public void timeDelay(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
