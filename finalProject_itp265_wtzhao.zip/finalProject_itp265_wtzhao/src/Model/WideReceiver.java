package Model;

import java.util.*;

import View.UIConsole;

/**
 * Brief description of code: WideReceiver class
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class WideReceiver extends Player implements Receive, java.io.Serializable{

	private Map<String, ArrayList<Integer>> wrStats;
	private ArrayList<Integer> receptions;
	private ArrayList<Integer> receivingYards;
	private ArrayList<Integer> receivingTD;
	
	Random rand = new Random();
	
	public WideReceiver(String name, String collegeTeam, String position, String height, String weight, String year,
			String birthPlace, Rating rating) {
		super(name, collegeTeam,position, height, weight, year, birthPlace, rating);
		// storing all of the quarterback's stats. 
		wrStats = new HashMap<>();
		receptions = new ArrayList<>();
		receivingYards = new ArrayList<>();
		receivingTD = new ArrayList<>();

		this.wrStats.put("Receptions",receptions);
		this.wrStats.put("Receiving Yards",receivingYards);
		this.wrStats.put("Receiving TD",receivingTD);
		for (String s : wrStats.keySet()) { // loops through all the attributes for the quarterback, sets their starting stats to be 0s
			for (int i = 0; i < 10; i++) { // 10 times
				wrStats.get(s).add(0);
			}
		}
	}
	
	// getters
	public Map<String, ArrayList<Integer>> getWrStats(){
		return this.wrStats;
	}
	
	public List<Integer> getReceptions() {
		return this.receptions;
	}
	
	public List<Integer> getReceivingYards() {
		return this.receivingYards;
	}
	
	public List<Integer> receivingTD() {
		return this.receivingTD;
	}
	
	public List<Double> getReceivingPoints(){ // getting the receiving points are just the points they score per week. no separate Map for this!
		return this.getPoints();
	}
	
	// calculate Passing stats
		public void calcReceivingStats(int index) {
			Integer calcReceptions = 0; Integer calcReceivingYards = 0; Integer calcReceivingTD = 0; 
			if (this.getRating().equals(Rating.HEISMAN)) { // heisman
				calcReceptions = UIConsole.randomIntInRange(6, 12); // between 6-13 receptions per game
				calcReceivingYards = UIConsole.randomIntInRange(70, 150); // between 70-150 receiving yards per game
				calcReceivingTD = UIConsole.probabilityNumsRange(0.20,1,4,0,2); // 20% chance 2-4 touchdowns, 80% 0-2 touchdowns
			}
			else if (this.getRating().equals(Rating.CAPTAIN)) { // captain
				calcReceptions = UIConsole.randomIntInRange(6, 10); // between 1-4 receptions per game
				calcReceivingYards = UIConsole.randomIntInRange(70, 120); // between 70-120 receiving yards per game
				calcReceivingTD = UIConsole.probabilityNumsRange(0.20,1,3,0,2); // 20% chance 2-4 touchdowns, 80% 0-2 touchdowns
			}
			else { // if just a starter
				calcReceptions = UIConsole.randomIntInRange(6, 8); // between 1-4 receptions per game
				calcReceivingYards = UIConsole.randomIntInRange(70, 100); // between 10-20 receiving yards per game
				calcReceivingTD = UIConsole.probabilityNumsRange(0.35,1,2,0,1); // 35% chance 1-2 touchdowns, 65% 0-1 touchdowns
			}
			this.receptions.set(index, calcReceptions);
			this.receivingYards.set(index, calcReceivingYards);
			this.receivingTD.set(index, calcReceivingTD);
		}
	
	// calculates the receiving stats
	public void calcWrStats(int index) {
		calcReceivingStats(index); // kind of a repeat, but keeping it consistent with other classes within this hierarchy
	}
	
	// calculates the total points in one week, both passing and rushing and stores inside Player POINTS array
	@Override
	public void calcWeeklyPoints(int index) {
		calcWrStats(index);
		double receptionsPoints = this.receptions.get(index) * 1.0; // 1 point for every reception
		double receivingYardsPoints = this.receivingYards.get(index) * .10; // 1 point for every 10 receiving yards
		double receivingTdPoints = this.receivingTD.get(index) * 6.0; // 6 points for every receiving TD
		double totalReceivingPoints = receptionsPoints + receivingYardsPoints + receivingTdPoints;
		this.getPoints().set(index, totalReceivingPoints); // just uses the ordinary this.totalPoints array, because this is the only way WRs score points
	}
	
	@Override
	// displays all of player information --> when user wants to "zoom in" and see more about the player
	public String toString() {
		String s =  this.printNameCollegePosition();
		s += "\n\tReceptions: " + this.sumInt(this.getReceptions());
		s += "\n\tReceiving Yards: " + this.sumInt(this.getReceivingYards());
		s += "\n\tReceiving TDs: " + this.sumInt(this.receivingTD());
		s += "\n\tTotal Receiving Points: " + this.sumDouble(this.getReceivingPoints());
		s += "\n\tTotal Points: " + this.getTotalPoints() + "\n";
		return s;
	}
}
