package Model;

import java.util.*;

import View.UIConsole;

/**
 * Brief description of code: Runningback class
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class Runningback extends Player implements Rush, Receive,java.io.Serializable{

	private Map<String, ArrayList<Integer>> rbStats;
	private ArrayList<Integer> rushYards;
	private ArrayList<Integer> rushTD;
	private ArrayList<Integer> fumbles;
	private ArrayList<Integer> receptions;
	private ArrayList<Integer> receivingYards;
	private ArrayList<Integer> receivingTD;
	
	private Map<String, ArrayList<Double>> pointsByCategory;
	private ArrayList<Double> rushingPoints;
	private ArrayList<Double> receivingPoints;
	
	Random rand = new Random();
	
	public Runningback(String name, String collegeTeam, String position, String height, String weight, String year,
			String birthPlace, Rating rating) {
		super(name, collegeTeam,position, height, weight, year, birthPlace, rating);
		// storing all of the quarterback's stats. 
		rbStats = new HashMap<>();
		rushYards = new ArrayList<>();
		rushTD = new ArrayList<>();
		fumbles = new ArrayList<>();
		receptions = new ArrayList<>();
		receivingYards = new ArrayList<>();
		receivingTD = new ArrayList<>();
		
		this.rbStats.put("Rush Yards",rushYards);
		this.rbStats.put("Rush TD",rushTD);
		this.rbStats.put("Fumbles",fumbles);
		this.rbStats.put("Receptions",receptions);
		this.rbStats.put("Receiving Yards",receivingYards);
		this.rbStats.put("Receiving TD",receivingTD);
		for (String s : rbStats.keySet()) { // loops through all the attributes for the quarterback, sets their starting stats to be 0s
			for (int i = 0; i < 10; i++) { // 10 times
				rbStats.get(s).add(0);
			}
		}
		// Creating a map to separate the points their quarterback scores by either passing or rushing
		pointsByCategory = new HashMap<>();
		rushingPoints = new ArrayList<Double>();
		receivingPoints = new ArrayList<Double>();
		this.pointsByCategory.put("Rushing Points",rushingPoints);
		this.pointsByCategory.put("Receiving Points",receivingPoints);
		for (String s : pointsByCategory.keySet()) { // loops through all the attributes for the kicker, sets their starting points to be 0s
			for (int i = 0; i < 10; i++) { // 10 times
				pointsByCategory.get(s).add(0.0);
			}
		}
	}
	
	// getters
	public Map<String, ArrayList<Integer>> getRbStats(){
		return this.rbStats;
	}
	
	public List<Integer> getRushYards() {
		return this.rushYards;
	}
	
	public List<Integer> getRushTD() {
		return this.rushTD;
	}
	
	public List<Integer> getFumbles() {
		return this.fumbles;
	}
	
	public List<Integer> getReceptions() {
		return this.receptions;
	}
	
	public List<Integer> getReceivingYards() {
		return this.receivingYards;
	}
	
	public List<Integer> receivingTD() {
		return this.receivingTD;
	}
	
	public List<Double> getRushingPoints(){
		return this.rushingPoints;
	}
	
	public List<Double> getReceivingPoints(){
		return this.receivingPoints;
	}
	
	// calculate rushing stats
	public void calcRushingStats(int index) {
		Integer calcRushYards = 0; Integer calcRushTD = 0; Integer calcFumble = 0;
		if (this.getRating().equals(Rating.HEISMAN)) { // HEISMAN
			calcRushYards = UIConsole.randomIntInRange(75, 175); // between 75-175 yards rushing per game
			calcRushTD = UIConsole.probabilityNumsRange(0.40, 0, 2, 0, 1); // 40% between 0-2 rushing TDS, 60% between 0-1 rushing TDs
			calcFumble = UIConsole.probabilityNums(0.20, 1, 0); // probability that they fumble
		}
		else if (this.getRating().equals(Rating.CAPTAIN)) { // CAPTAIN
			calcRushYards = UIConsole.randomIntInRange(50, 150); 
			calcRushTD = UIConsole.probabilityNumsRange(0.25, 0, 2, 0, 1); // 25% chance between 0-2 TD, 70% chance between 0-1 TD
			calcFumble = UIConsole.probabilityNums(0.30, 1, 0); // 30% chance have 1 fumble, 70% chance 0 fumbles
		}
		else { // STARTER
			calcRushYards = UIConsole.randomIntInRange(25,125);
			calcRushTD = UIConsole.probabilityNumsRange(0.10, 0, 2, 0, 1); // 10% chance between 0-2 TD, 70% chance between 0-1 TD
			calcFumble = UIConsole.probabilityNums(0.40, 1, 0); // 40% chance have 1 fumble, 60% chance 0 fumbles
		}
		this.rushYards.set(index, calcRushYards);
		this.rushTD.set(index, calcRushTD);
		this.fumbles.set(index, calcFumble);
	}
	
	// calculate Passing stats
	public void calcReceivingStats(int index) {
		Integer calcReceptions = 0; Integer calcReceivingYards = 0; Integer calcReceivingTD = 0; 
		if (this.getRating().equals(Rating.HEISMAN)) { // heisman
			calcReceptions = UIConsole.randomIntInRange(1, 5); // between 1-5 receptions per game
			calcReceivingYards = UIConsole.randomIntInRange(10, 30); // between 10-30 receiving yards per game
			calcReceivingTD = UIConsole.probabilityNums(0.20, 1, 0); // 15% chance they catch a touchdown
		}
		else if (this.getRating().equals(Rating.CAPTAIN)) { // captain
			calcReceptions = UIConsole.randomIntInRange(1, 4); // between 1-4 receptions per game
			calcReceivingYards = UIConsole.randomIntInRange(10, 25); // between 10-25 receiving yards per game
			calcReceivingTD = UIConsole.probabilityNums(0.15, 1, 0); // 10% chance they catch a touchdown
		}
		else { // if just a starter
			calcReceptions = UIConsole.randomIntInRange(1, 3); // between 1-4 receptions per game
			calcReceivingYards = UIConsole.randomIntInRange(10, 20); // between 10-20 receiving yards per game
			calcReceivingTD = UIConsole.probabilityNums(0.10, 1, 0); // 5% chance they catch a touchdown
		}
		this.receptions.set(index, calcReceptions);
		this.receivingYards.set(index, calcReceivingYards);
		this.receivingTD.set(index, calcReceivingTD);
	}
	
	
	// calculates the stats, just does the two methods above and combines into one
	public void calcRbStats(int index) {
		calcRushingStats(index);
		calcReceivingStats(index);
	}
	
	// calculates the points just from rushing
	public double calcRushingPoints(int index) {
		double rushYardPoints = this.rushYards.get(index) * 0.1; // 1 point for every 10 yards rushed
		double rushTdPoints = this.rushTD.get(index) * 6.0; // 6 points for every TD rushed for
		double fumblePoints = this.fumbles.get(index) * -2.0; // -2 points for every fumble
		double totalRushingPoints = rushYardPoints + rushTdPoints + fumblePoints;
		this.rushingPoints.set(index, totalRushingPoints); // fills in the pointsByCategory rushing points with the just calculated rushing points
		return totalRushingPoints;
	}
	
	// calculates the points just from receiving
	public double calcReceivingPoints(int index) {
		double receptionsPoints = this.receptions.get(index) * 1.0; // 1 point for every reception
		double receivingYardsPoints = this.receivingYards.get(index) * .10; // 1 point for every 10 receiving yards
		double receivingTdPoints = this.receivingTD.get(index) * 6.0; // 6 points for every receiving TD
		double totalPassingPoints = receptionsPoints + receivingYardsPoints + receivingTdPoints;
		this.receivingPoints.set(index, totalPassingPoints); // fills in the pointsByCategory passing points with the just calculated passing points
		return totalPassingPoints;
	}
	
	// calculates the total points in one week, both passing and rushing and stores inside Player POINTS array
	@Override
	public void calcWeeklyPoints(int index) {
		calcRbStats(index);
		double totalPoints = calcRushingPoints(index) + calcReceivingPoints(index);
		this.getPoints().set(index, totalPoints); // sets the total amount of points to that week's index
	}
	
	@Override
	// displays all of player information --> when user wants to "zoom in" and see more about the player
	public String toString() {
		String s =  this.printNameCollegePosition();
		s += "\n\tRushingYards: " + this.sumInt(this.getRushYards());
		s += "\n\tRushingTDs: " + this.sumInt(this.getRushTD());
		s += "\n\tFumbles: " + this.sumInt(this.getFumbles());
		s += "\n\tReceptions: " + this.sumInt(this.getReceptions());
		s += "\n\tReceiving Yards: " + this.sumInt(this.getReceivingYards());
		s += "\n\tReceiving TDs: " + this.sumInt(this.receivingTD());
		s += "\n\tTotal Rushing Points: " + this.sumDouble(this.getRushingPoints());
		s += "\n\tTotal Receiving Points: " + this.sumDouble(this.getReceivingPoints());
		s += "\n\tTotal Points: " + this.getTotalPoints() + "\n";
		return s;
	}
}
