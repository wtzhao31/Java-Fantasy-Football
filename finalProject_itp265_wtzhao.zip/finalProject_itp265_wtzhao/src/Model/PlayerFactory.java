package Model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class PlayerFactory implements java.io.Serializable{

	private List<Player> allPlayers;
	//private static final String FILE_NAME = "src/Players.tsv";
	
	public PlayerFactory(String fileName) {
		allPlayers = readInPlayersFromFile(fileName);
	}

	// code taken from BookFileReader from our lecture
	private List<Player> readInPlayersFromFile(String fileName) {
		List<Player>allPlayersLocal = new ArrayList<>();
		// try with resources block -- newer structure from Java 1.7+
		try(FileInputStream fis = new FileInputStream(fileName);
				Scanner scan = new Scanner(fis))
		{  // NOTE: resources will be closed automatically
			scan.nextLine();
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				try {
					Player player = parseStringIntoPlayer(line);// "risky" method
					allPlayersLocal.add(player);
				} catch (BadPlayerException e) {
					System.err.println("Skipping bad player: " + e.getMessage()); // skips the bad book
				} 
			}
		}
		catch (FileNotFoundException e) {
			System.err.println("File not found: " + fileName);
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return allPlayersLocal;
	}

	// parses a line of the file into Player
	private Player parseStringIntoPlayer(String line) throws BadPlayerException{
		// name, college, position, height, weight, year, place of birth, rating
		try { // making a book, assuming file is good
			Scanner sc = new Scanner(line); // reading the file IF it is how it is supposed to be
			sc.useDelimiter("	");
			String name = sc.next();
			String college = sc.next();
			String position = sc.next();
			String height = sc.next();
			String weight = sc.next();
			String year = sc.next();
			String placeOfBirth = sc.next();
			String rating = sc.next();
			Rating ratingEnum = null;
			if (rating.equals("Heisman")) {
				ratingEnum = Rating.HEISMAN;
			}
			else if (rating.equals("Captain")) {
				ratingEnum = Rating.CAPTAIN;
			}
			else {
				ratingEnum = Rating.STARTER;
			}
			sc.close(); // oops don't forget to close scanner
			// constructing the players based on their position
			if (position.equals("QB")) {
				return new Quarterback(name, college, position, height, weight, year, placeOfBirth, ratingEnum);
			}
			else if (position.equals("RB")) {
				return new Runningback(name, college, position, height, weight, year, placeOfBirth, ratingEnum);
			}
			else if (position.equals("WR")) {
				return new WideReceiver(name, college, position, height, weight, year, placeOfBirth, ratingEnum);
			}
			else if (position.equals("TE")) {
				return new TightEnd(name, college, position, height, weight, year, placeOfBirth, ratingEnum);
			}
			else {
				return new Kicker(name, college, position, height, weight, year, placeOfBirth, ratingEnum);
			}
			
		} // if the "try" code doesn't work, immediately jumps here
		catch(Exception e) {
			throw new BadPlayerException("Problem formatting " + line + " as a book");
		}
	}
	
	// allows the list of new players to be returned whenever creating a new League
	public List<Player> getAllPlayers(){
		return this.allPlayers;
	}
	/*
	public static void main(String[] args) {
		PlayerFactory p = new PlayerFactory();
		for (Player player : p.allPlayers) {
			System.out.println(player);
		}
	}*/

}