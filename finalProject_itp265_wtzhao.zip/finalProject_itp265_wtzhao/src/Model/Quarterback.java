package Model;

import java.util.*;

import View.UIConsole;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class Quarterback extends Player implements Rush, java.io.Serializable{

	private Map<String, ArrayList<Integer>> qbStats;
	private ArrayList<Integer> passYards;
	private ArrayList<Integer> passTD;
	private ArrayList<Integer> interceptions;
	private ArrayList<Integer> rushYards;
	private ArrayList<Integer> rushTD;
	private ArrayList<Integer> fumbles;
	
	private Map<String, ArrayList<Double>> pointsByCategory;
	private ArrayList<Double> passingPoints;
	private ArrayList<Double> rushingPoints;
	
	Random rand = new Random();
	
	public Quarterback(String name, String collegeTeam, String position, String height, String weight, String year,
			String birthPlace, Rating rating) {
		super(name, collegeTeam,position, height, weight, year, birthPlace, rating);
		// storing all of the quarterback's stats. 
		qbStats = new HashMap<>();
		passYards = new ArrayList<>();
		passTD = new ArrayList<>();
		interceptions = new ArrayList<>();
		rushYards = new ArrayList<>();
		rushTD = new ArrayList<>();
		fumbles = new ArrayList<>();
		this.qbStats.put("Pass Yards",passYards); // TODO change the key into something that would be printed out
		this.qbStats.put("Pass TD",passTD);
		this.qbStats.put("Interceptions",interceptions);
		this.qbStats.put("Rush Yards",rushYards);
		this.qbStats.put("Rush TD",rushTD);
		this.qbStats.put("Fumbles",fumbles);
		for (String s : qbStats.keySet()) { // loops through all the attributes for the quarterback, sets their starting stats to be 0s
			for (int i = 0; i < 10; i++) { // 10 times
				qbStats.get(s).add(0);
			}
		}
		// Creating a map to separate the points the quarterback scores by either passing or rushing
		pointsByCategory = new HashMap<>();
		passingPoints = new ArrayList<Double>();
		rushingPoints = new ArrayList<Double>();
		this.pointsByCategory.put("Passing Points",passingPoints);
		this.pointsByCategory.put("Rushing Points",rushingPoints);
		for (String s : pointsByCategory.keySet()) { // loops through all the attributes for the kicker, sets their starting points to be 0s
			for (int i = 0; i < 10; i++) { // 10 times
				pointsByCategory.get(s).add(0.0);
			}
		}
	}
	
	public Map<String, ArrayList<Integer>> getQbStats(){
		return this.qbStats;
	}
	
	// getters
	public List<Integer> getPassYards() {
		return this.passYards;
	}

	public List<Integer> getPassTD() {
		return this.passTD;
	}

	public List<Integer> getInterceptions() {
		return this.interceptions;
	}

	public List<Integer> getRushYards() {
		return this.rushYards;
	}
	
	public List<Integer> getRushTD() {
		return this.rushTD;
	}
	
	public List<Integer> getFumbles() {
		return this.fumbles;
	}
	
	public List<Double> getPassingPoints(){
		return this.passingPoints;
	}
	
	public List<Double> getRushingPoints(){
		return this.rushingPoints;
	}

	// calculate Passing stats
	public void calcPassingStats(int index) {
		Integer calcPassYards = 0; Integer calcPassTD = 0; Integer calcInterceptions = 0;
		if (this.getRating().equals(Rating.HEISMAN)) { // heisman
			calcPassYards = UIConsole.randomIntInRange(275, 375); // between 300 and 400 pass yards per game
			calcPassTD = UIConsole.randomIntInRange(3, 4); // between 3-5 TDs per game
			calcInterceptions = UIConsole.probabilityNums(0.15, 1, 0); // probability that they throw one interception: 15%
		}
		else if (this.getRating().equals(Rating.CAPTAIN)) { // captain
			calcPassYards = UIConsole.randomIntInRange(250, 350); // between 200 and 350 pass yards per game, some overlap with Heisman QBs
			calcPassTD = UIConsole.randomIntInRange(2, 4); // between 2-4 TDs per game
			calcInterceptions = UIConsole.probabilityNumsRange(.40, 1, 2, 0, 0); // 40% chance throw 1-2 picks, 60% chance throw 0-1 picks
		}
		else { // if just a starter
			calcPassYards = UIConsole.randomIntInRange(225,325);
			calcPassTD = UIConsole.randomIntInRange(2, 3);
			calcInterceptions = UIConsole.probabilityNumsRange(.6, 1, 3, 0, 1); // 60% chance throw 1-3 picks
		}
		this.passYards.set(index, calcPassYards);
		this.passTD.set(index, calcPassTD);
		this.interceptions.set(index, calcInterceptions);
	}
	
	// calculate rushing stats
	public void calcRushingStats(int index) {
		Integer calcRushYards = 0; Integer calcRushTD = 0; Integer calcFumble = 0;
		if (this.getRating().equals(Rating.HEISMAN)) { // HEISMAN
			calcRushYards = UIConsole.randomIntInRange(-10, 60); // between 50-75 yards rushing per game
			calcRushTD = UIConsole.probabilityNumsRange(0.15, 0, 2, 0, 1); // 20% between 0-2 rushing TDS, 70% between 0-1 rushing TDs
			calcFumble = UIConsole.probabilityNums(0.2, 1, 0); // probability that they fumble
		}
		else if (this.getRating().equals(Rating.CAPTAIN)) { // CAPTAIN
			calcRushYards = UIConsole.randomIntInRange(-10, 45); 
			calcRushTD = UIConsole.probabilityNums(0.3, 1, 0); // 30% 1 rushing TD, 70% 0 rushing TD
			calcFumble = UIConsole.probabilityNums(0.25, 1, 0); // 25% chance have 1 fumbles, 75% chance 0 fumbles
		}
		else { // STARTER
			calcRushYards = UIConsole.randomIntInRange(-10,35);
			calcRushTD = UIConsole.probabilityNums(0.25, 1, 0); // 20% chance 1 rushing TD, 80% chance 0 rushing TD
			calcFumble = UIConsole.probabilityNumsRange(.35, 1, 2, 0, 1); 
		}
		this.rushYards.set(index, calcRushYards);
		this.rushTD.set(index, calcRushTD);
		this.fumbles.set(index, calcFumble);
	}
	
	// calculates the stats, just does the two methods above and combines into one
	public void calcQbStats(int index) {
		calcPassingStats(index);
		calcRushingStats(index);
	}
	
	// calculates the points just from passing
	public double calcPassingPoints(int index) {
		double passYardsPoints = this.passYards.get(index) * .04; // 1 point for every 25 yards passed
		double passTdPoints = this.passTD.get(index) * 4.0; // 4 points for every pass TD
		double interceptionPoints = this.interceptions.get(index) * -2.0; // -2 points for every interception thrown
		double totalPassingPoints = passYardsPoints + passTdPoints + interceptionPoints;
		this.passingPoints.set(index, totalPassingPoints); // fills in the pointsByCategory passing points with the just calculated passing points
		return totalPassingPoints;
	}
	
	// calculates the points just from rushing
	public double calcRushingPoints(int index) {
		double rushYardPoints = this.rushYards.get(index) * 0.1; // 1 point for every 10 yards rushed
		double rushTdPoints = this.rushTD.get(index) * 6.0; // 6 points for every TD rushed for
		double fumblePoints = this.fumbles.get(index) * -2.0; // -2 points for every fumble
		double totalRushingPoints = rushYardPoints + rushTdPoints + fumblePoints;
		this.rushingPoints.set(index, totalRushingPoints); // fills in the pointsByCategory rushing points with the just calculated rushing points
		return totalRushingPoints;
	}
	
	// calculates the total points in one week, both passing and rushing and stores inside Player POINTS array
	@Override
	public void calcWeeklyPoints(int index) {
		calcQbStats(index);
		double totalPoints = calcPassingPoints(index) + calcRushingPoints(index);
		this.getPoints().set(index, totalPoints); // sets the total amount of points to that week's index
	}

	@Override
	// displays all of player information --> when user wants to "zoom in" and see more about the player
	public String toString() {
		String s =  this.printNameCollegePosition();
		s += "\n\tPassing Yards: " + this.sumInt(this.getPassYards());
		s += "\n\tPassing TDs: " + this.sumInt(this.getPassTD());
		s += "\n\tInterceptions: " + this.sumInt(this.getInterceptions());
		s += "\n\tRushingYards: " + this.sumInt(this.getRushYards());
		s += "\n\tRushingTDs: " + this.sumInt(this.getRushTD());
		s += "\n\tFumbles: " + this.sumInt(this.getFumbles());
		s += "\n\tTotal Passing Points: " + this.sumDouble(this.getPassingPoints());
		s += "\n\tTotal Rushing Points: " + this.sumDouble(this.getRushingPoints());
		s += "\n\tTotal Points: " + this.getTotalPoints() + "\n";
		return s;
	}
}
