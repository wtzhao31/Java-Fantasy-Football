package Model;

public class BadPlayerException extends Exception {
	public BadPlayerException() {
		super();
	}
	public BadPlayerException(String msg) {
		super(msg);
	}
}