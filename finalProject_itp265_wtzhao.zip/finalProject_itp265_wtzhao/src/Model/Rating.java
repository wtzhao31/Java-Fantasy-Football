package Model;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public enum Rating implements java.io.Serializable {
	HEISMAN(),
	CAPTAIN(),
	STARTER();
}
