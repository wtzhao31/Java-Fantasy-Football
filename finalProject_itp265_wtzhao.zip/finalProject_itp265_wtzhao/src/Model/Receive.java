package Model;

import java.util.List;

/**
 * Brief description of code: interface for Players that can receive (RB, WR, TE)
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public interface Receive {
	public void calcReceivingStats(int index);
	public List<Double> getReceivingPoints(); // will make it easier to just get the amount of points from rushing per week
											// so when I'm printing the leaderboard it will be easier to sift through
}
