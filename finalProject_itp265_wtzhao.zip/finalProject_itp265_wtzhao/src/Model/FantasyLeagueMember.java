package Model;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class FantasyLeagueMember implements java.io.Serializable{

	protected String name;
	protected String email;
	protected String password;
	
	public FantasyLeagueMember(String name, String email, String password) {
		this.name = name;
		this.email = email;
		this.password = password;
	}
	
	// getters
	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPassword() {
		return password;
	}


	@Override
	public String toString() {
		return "[name=" + name + ", email=" + email + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FantasyLeagueMember other = (FantasyLeagueMember) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}
	
	
	

}
