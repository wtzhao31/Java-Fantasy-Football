package Model;

import java.util.List;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public interface Rush {
	public void calcRushingStats(int index);
	public List<Double> getRushingPoints(); // will make it easier to just get the amount of points from rushing per week
											// so when I'm printing the leaderboard it will be easier to sift through
}
