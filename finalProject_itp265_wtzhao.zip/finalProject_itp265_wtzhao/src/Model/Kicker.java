package Model;
import java.util.*;

/**
 * Brief description of code: 
 * 
 * @author Winfield Zhao
 * ITP 265, Fall 2020. Coffee Section
 * Assignment xx WEEK ##
 * Email: wtzhao@usc.edu
 */
public class Kicker extends Player implements java.io.Serializable{

	private Map<String, ArrayList<Integer>> kickerStats; // maps a String (fgMade, fgMissed, etc...) to an ArrayList of size 10 with all their stats
	private ArrayList<Integer> fgMade;
	private ArrayList<Integer> fgMissed;
	private ArrayList<Integer> xpMade;
	private ArrayList<Integer> xpMissed;
	
	private Random rand = new Random();
	
	public Kicker(String name, String collegeTeam, String position, String height, String weight, String year,
			String birthPlace, Rating rating) {
		super(name, collegeTeam,position, height, weight, year, birthPlace, rating);
		this.kickerStats = new HashMap<>(); // initializes the hashMap
		fgMade = new ArrayList<>();
		fgMissed = new ArrayList<>();
		xpMade = new ArrayList<>();
		xpMissed = new ArrayList<>();
		
		this.kickerStats.put("FG Made", fgMade); // creates all of the different data containers for every Kicker
		this.kickerStats.put("FG Missed", fgMissed);
		this.kickerStats.put("XP Made", xpMade);
		this.kickerStats.put("XP Missed", xpMissed);
		for (String s : kickerStats.keySet()) { // loops through all the attributes for the kicker, sets their starting stats to be 0s
			for (int i = 0; i < 10; i++) { // 10 times
				kickerStats.get(s).add(0);
			}
		}
	}
	
	// getters
	public Map<String, ArrayList<Integer>> getKickerStats(){
		return this.kickerStats;
	}
	
	public List<Integer> getFgMade() {
		return this.fgMade;
	}

	public List<Integer> getFgMissed() {
		return this.fgMissed;
	}

	public List<Integer> getXpMade() {
		return this.xpMade;
	}

	public List<Integer> getXpMissed() {
		return this.xpMissed;
	}

	public List<Double> getKickerPoints(){
		return this.getPoints();
	}
	
	// randomly generates a Kicker's statistics depending on their Rating level 
	public void calcKickerStats(int index) {
		Integer calcFgMade = 0; Integer calcFgMissed = 0; Integer calcXpMade = 0; Integer calcXpMissed = 0;
		if (this.getRating().equals(Rating.HEISMAN)) { // heisman
			calcFgMade = rand.nextInt(4) + 1; // makes between 1-4 FGs a game
			calcFgMissed = 0; // never misses a FG
			calcXpMade = rand.nextInt(4) + 1; // makes between 1-4 XPs per game (4 touchdowns) 
			calcXpMissed = 0; // never misses an XP
		}
		else if (this.getRating().equals(Rating.CAPTAIN)) { // captain
			double probability = rand.nextDouble();
			calcFgMade = rand.nextInt(3) + 1; // makes between 1-3 FGs a game
			calcXpMade = rand.nextInt(4) + 1; // makes between 1-4 XPs per game
			if (probability < 0.5) { // 66% chance that they don't miss a kick
				calcFgMissed = 0;
				calcXpMissed = 0;
			}
			else { // 33% chance that they miss an extra point and a field goal
				calcFgMissed = 1;
				calcXpMissed = 1;
			}
		}
		else { // if just a starter
			double probability = rand.nextDouble();
			calcFgMade = rand.nextInt(2) + 1; // makes between 1-2 FGs a game
			calcXpMade = rand.nextInt(4) + 1; // makes between 1-4 XPs per game
			if (probability < 0.35) { // 25% chance that they don't miss a kick
				calcFgMissed = 0;
				calcXpMissed = 0;
			}
			else {
				calcFgMissed = calcFgMade; // miss as many FGs made
				calcXpMissed = calcXpMade;
			}
		}
		
		// updating the Kicker's arrays
		this.fgMade.set(index, calcFgMade);
		this.fgMissed.set(index, calcFgMissed);
		this.xpMade.set(index, calcXpMade);
		this.xpMissed.set(index, calcXpMissed);
	}
	
	@Override
	public void calcWeeklyPoints(int index) {
		calcKickerStats(index);
		double fgMadePoints = this.fgMade.get(index) * 3.0; // 3 points for every field goal made
		double fgMissedPoints = this.fgMissed.get(index) * 2.0; // lose 2 points for every field goal missed
		double xpMadePoints = this.xpMade.get(index) * 1.0; // 1 point for every XP made
		double xpMissedPoints = this.xpMissed.get(index) * 0.5; // 3 points for every field goal made
		
		double totalPoints = fgMadePoints - fgMissedPoints + xpMadePoints - xpMissedPoints; // calculates the points that week
		
		this.getPoints().set(index, totalPoints); // sets the total amount of points to that week's index
	}
	
	@Override
	// displays all of player information --> when user wants to "zoom in" and see more about the player
	public String toString() {
		String s =  this.printNameCollegePosition();
		s += "\n\tField Goals Made: " + this.sumInt(this.getFgMade());
		s += "\n\tField Goals Missed: " + this.sumInt(this.getFgMissed());
		s += "\n\tExtra Points Made: " + this.sumInt(this.getXpMade());
		s += "\n\tExtra Points Missed: " + this.sumInt(this.getXpMissed());
		s += "\n\tTotal Kicking Points: " + this.sumDouble(this.getKickerPoints());
		s += "\n\tTotal Points: " + this.getTotalPoints() + "\n";
		return s;
	}
}
