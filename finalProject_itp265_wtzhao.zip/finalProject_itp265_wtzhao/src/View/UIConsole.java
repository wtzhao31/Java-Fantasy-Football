package View;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

public class UIConsole implements java.io.Serializable{

	transient private Scanner sc;
	
	/**
	 * Constructor sets up a Scanner to be used by the class in order to read input from the standard console window (System.in)
	 */
	public UIConsole() {
		sc = new Scanner(System.in);
	}
	
	/**
	 * Short-cut helper method for print
	 * @param output: The String to be printed
	 */
	public void print(String output) {
		System.out.println(output);
	}
	
	public void print(int output) {
		System.out.println(output);
	}
	/**
	 * Short-cut helper method that prints a String with a series of stars around it.
	 * @param output: The String to be printed
	 */
	public void printPretty(String output) {
		System.out.println("***********************************************************************************************");
		System.out.println(output);
		System.out.println("***********************************************************************************************");
	}
	
	/**
	 * Short-cut helper method that prints a List with a series of stars around it.
	 * @param output: The List to be printed
	 */
	public void printPretty(ArrayList list) {
		System.out.println("***********************************************************************************************");
		for(Object o: list) {
			System.out.println(o);
		}
		System.out.println("***********************************************************************************************");
	}
	/**
	 * Prompt the user and read one line of text as a String
	 * @param prompt: the question to ask the user
	 * @return: a line of user input (including spaces, until they hit enter)
	 */
	public String inputLine(String prompt) {
		System.out.print(prompt + "\n>");
		return sc.nextLine();
	}
	
	/**
	 * Prompt the user and read one word of text as a String
	 * @param prompt: the question to ask the user
	 * @return: a one word String - if the user enters multiple words, all other input until the return will be discarded.
	 */
	public String inputWord(String prompt) {
		System.out.print(prompt + "\n>");
		String word = sc.next();
		sc.nextLine(); // remove any "garbage" (like extra whitespace or the return key) after the one word that is read in
		return word;
	}
	
	/**
	 * Prompt the user and read one word - which must match either option1 or option2 parameters.
	 * @param prompt: the question to ask the user (should include the two valid options the user should choose from)
	 * @param option1 : One string option for the user to choose.
	 * @param option2: the other string option for the user to choose.
	 * @return: A string matching either option1 or option2
	 */
	public String inputWord(String prompt, String option1, String option2) {
		
		System.out.print(prompt + "\n>");
		String word = sc.nextLine();
		while(! (word.equalsIgnoreCase(option1) || word.equalsIgnoreCase(option2))) {
			System.out.println(word + " not recognized as " + option1 + " or " + option2);
			System.out.println(prompt);
			word = sc.nextLine();
		}
		return word;
	}
	
	// save as above, but for 5 options
	public String inputWord(String prompt, String option1, String option2, String option3, String option4, String option5) {
		System.out.print(prompt + "\n>");
		String word = sc.nextLine();
		while(! (word.equals(option1) || word.equals(option2) || word.equals(option3) || word.equals(option4) || word.equals(option5))) {
			System.out.println(word + " not recognized as " + option1 + ", " + option2 + ", " + option3 + ", " + option4 + ", or " + option5);
			System.out.println(prompt);
			word = sc.nextLine();
		}
		return word;
	}
	/**
	 * Prompt the user and read an int, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int 
	 */
	public int inputInt(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner does not see an int, get rid of garbage and ask again.
		while (!sc.hasNextInt()) {
			String garbage = sc.nextLine();
			System.out.println("Didn't recognize " + garbage + " as an integer...");
			System.out.println(prompt);
		}
		int num = sc.nextInt();
		sc.nextLine(); // clear the buffer
		return num;
	}
	
	/**
	 * Prompt the user and read an int between (inclusive) of minValue and maxValue, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int between minValue and maxValue
	 */
	public int inputInt(String prompt, int minValue, int maxValue) {
		int num = inputInt(prompt); // make sure you get a num
		while(num < minValue || num > maxValue) {
			System.out.println(num + " is not in the allowed range: [" + minValue
					+ "-" + maxValue + "]");
			num = inputInt(prompt); // make sure you get a num

		}
		return num;
	}
	

	/**
	 * Prompt the user and read an int between (inclusive) of minValue and maxValue, 
	 * (or sentinel quitValue) clearing whitespace or the enter after the number
	 * @param prompt the question to ask the user
	 * @param minValue
	 * @param maxValue
	 * @param quitValue
	 * @return an int between minValue and maxValue (or quit sentinel value)
	 */
	public int inputInt(String prompt, int minValue, int maxValue, int quitValue) {
		int num = inputInt(prompt); // make sure you get a num
		while(num != quitValue && (num < minValue || num > maxValue)) {
			System.out.println(num + " is not in the allowed range: [" + minValue
					+ "-" + maxValue + "] (or " + quitValue + " to quit)");
			num = inputInt(prompt); // make sure you get a num
		}
		return num;
	}
	/**
	 * Prompt the user and read a postive (>=0) int, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: an int >= 0
	 */
	public int inputPostiveInt(String prompt) {
		// use the fact inputInt works....
		int num = inputInt(prompt); // off-loaded work
		while(num < 0) { //not positive....
			System.out.println("Need a positive number, try again");
			num = inputInt(prompt);
		}
		return num;
		
	}
	/**
	 * Prompt the user and read a floating point number, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: a double value 
	 */
	public double inputDouble(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner does not see a double, get rid of garbage and ask again.
		while (!sc.hasNextDouble()) {
			String garbage = sc.nextLine();
			System.out.println("Didn't recognize " + garbage + " as a double.");
			System.out.println(prompt);
		}
		double num = sc.nextDouble();
		sc.nextLine(); // clear the buffer
		return num;
	}
	/**
	 * Prompt the user and read a boolean value, clearing whitespace or the enter after the number
	 * @param prompt: the question to ask the user 
	 * @return: a boolean value 
	 */
	public boolean inputBoolean(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner does not see a boolean, get rid of garbage and ask again.
		while (!sc.hasNextBoolean()) {
			String garbage = sc.nextLine();
			System.out.println("Didn't recognize " + garbage + " as a boolean value. Must enter: "
					+ "\"true\" or \"false\"");
			System.out.println(prompt);
		}
		boolean value = sc.nextBoolean();
		sc.nextLine(); // clear the buffer
		return value;
	}
	
	/**
	 * Prompt the user enter yes or no (will match y/yes and n/no any case) and return true for yes and false for no.
	 * @param prompt: the question to ask the user 
	 * @return: a boolean value 
	 */
	public boolean inputYesNoAsBoolean(String prompt) {
		System.out.print(prompt + "\n>");
		// if scanner is seeing BAD input... loop to get good input
		String answer = sc.nextLine().toLowerCase();
		while ( ! (answer.equals("y") || answer.equals("yes") 
					|| answer.equals("n") || answer.equals("no") )) {
		
			System.out.println("Didn't recognize " + answer + " as yes or no...");
			System.out.println(prompt);
			answer = sc.nextLine().toLowerCase();
		}
		//end of loop = good input
		
		if(answer.equals("y") || answer.equals("yes")) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// returns a random int between a min and a max
	// min <= randomNumber < max --> excludes max number
	public static int randomIntInRange(int min, int max) {
		Random rand = new Random();
		return rand.nextInt(max - min + 1) + min; // got this code from baeldung.com
	}

	// returns which of two numbers something will return based on probability restriction
	public static int probabilityNums(double probRestriction, int lower, int upper) {
		Random rand = new Random();
		int probabilityNums = 0; // return value
		double probability = rand.nextDouble(); // create a random double
		if (probability < probRestriction) { // if the random double is less than the restriction
			probabilityNums = lower;
		}
		else {
			probabilityNums = upper;
		}
		return probabilityNums;
	}
	
	public static int probabilityNumsRange(double probRestriction, int lowerMin, int lowerMax, int upperMin, int upperMax) {
		Random rand = new Random();
		int probabilityNums = 0; // return value
		double probability = rand.nextDouble(); // create a random double
		if (probability < probRestriction) { // if the random double is less than the restriction
			probabilityNums = randomIntInRange(lowerMin, lowerMax); // probability for a RANGE of values
		}
		else {
			probabilityNums = randomIntInRange(upperMin, upperMax);
		}
		return probabilityNums;
	}
}